import React, { useState } from 'react';
import { AnomalyData, FilterType } from '../types/dashboard';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface AnomalyTableProps {
  data: AnomalyData[];
  onRowClick: (anomaly: AnomalyData) => void;
}

const AnomalyTable: React.FC<AnomalyTableProps> = ({ data, onRowClick }) => {
  const [activeFilter, setActiveFilter] = useState('Device');
  
  const filters: FilterType[] = [
    { id: 'Device', label: 'Device', active: true },
    { id: 'LTC', label: 'LTC', active: false },
    { id: 'Category', label: 'Category', active: false },
    { id: 'Sub-category', label: 'Sub-category', active: false },
    { id: 'MDA', label: 'MDA', active: false },
    { id: 'SDA', label: 'SDA', active: false },
  ];

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h2 className="text-lg font-semibold text-gray-800 mb-4">
        Anomaly Breakdown
      </h2>
      
      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-2 mb-6 border-b">
        {filters.map((filter) => (
          <button
            key={filter.id}
            onClick={() => setActiveFilter(filter.id)}
            className={`px-4 py-2 text-sm font-medium rounded-t-lg transition-all ${
              activeFilter === filter.id
                ? 'bg-blue-600 text-white border-b-2 border-blue-600'
                : 'text-gray-600 hover:text-blue-900 hover:bg-gray-50'
            }`}
          >
            {filter.label}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="overflow-x-auto overflow-y-auto max-h-80">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="text-left py-3 px-4 font-medium text-gray-600">Period</th>
              <th className="text-left py-3 px-4 font-medium text-gray-600">Metric</th>
              <th className="text-left py-3 px-4 font-medium text-gray-600">Anomaly Score</th>
              <th className="text-left py-3 px-4 font-medium text-gray-600">Direction</th>
              <th className="text-left py-3 px-4 font-medium text-gray-600">MoM %</th>
              <th className="text-left py-3 px-4 font-medium text-gray-600">YoY %</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item, index) => (
              <tr
                key={index}
                onClick={() => onRowClick(item)}
                className={`border-b border-gray-100 cursor-pointer transition-all hover:bg-gray-50 ${
                  item.direction === 'up' 
                    ? 'bg-green-50 hover:bg-green-100' 
                    : 'bg-red-50 hover:bg-red-100'
                }`}
              >
                <td className="py-4 px-4 text-sm">{item.period}</td>
                <td className="py-4 px-4 text-sm font-medium">{item.metric}</td>
                <td className="py-4 px-4 text-sm">
                  <span className={`font-semibold ${
                    item.anomalyScore > 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {Math.abs(item.anomalyScore).toFixed(1)}
                  </span>
                </td>
                <td className="py-4 px-4">
                  {item.direction === 'up' ? (
                    <TrendingUp className="w-5 h-5 text-green-500" />
                  ) : (
                    <TrendingDown className="w-5 h-5 text-red-500" />
                  )}
                </td>
                <td className="py-4 px-4 text-sm">
                  <span className={`font-semibold ${
                    item.momPercent > 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {item.momPercent > 0 ? '+' : ''}{item.momPercent.toFixed(1)}%
                  </span>
                </td>
                <td className="py-4 px-4 text-sm">
                  <span className={`font-semibold ${
                    item.yoyPercent > 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {item.yoyPercent > 0 ? '+' : ''}{item.yoyPercent.toFixed(1)}%
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AnomalyTable;
import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface AttributionChartProps {
  data: { [key: string]: number };
  onBarClick: (segment: string, value: number) => void;
}

const AttributionChart: React.FC<AttributionChartProps> = ({ data, onBarClick }) => {
  const chartData = {
    labels: Object.keys(data),
    datasets: [
      {
        label: 'Revenue Impact',
        data: Object.values(data),
        backgroundColor: Object.values(data).map(value => 
          value > 0 ? 'rgba(39, 174, 96, 0.8)' : 'rgba(215, 38, 61, 0.8)'
        ),
        borderColor: Object.values(data).map(value => 
          value > 0 ? 'rgba(39, 174, 96, 1)' : 'rgba(215, 38, 61, 1)'
        ),
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            const value = context.parsed.y;
            return `Impact: $${(value / 1000).toFixed(1)}k`;
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: (value: any) => `$${(value / 1000).toFixed(0)}k`,
        },
        grid: {
          color: 'rgba(0, 0, 0, 0.1)',
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
    onClick: (event: any, elements: any) => {
      if (elements.length > 0) {
        const dataIndex = elements[0].index;
        const segment = Object.keys(data)[dataIndex];
        const value = Object.values(data)[dataIndex];
        onBarClick(segment, value);
      }
    },
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h2 className="text-lg font-semibold text-gray-800 mb-4">
        Revenue Variance Attribution
      </h2>
      <div className="h-80">
        <Bar data={chartData} options={options} />
      </div>
    </div>
  );
};

export default AttributionChart;
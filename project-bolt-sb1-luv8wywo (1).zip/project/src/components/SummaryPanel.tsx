import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Pie, Bar } from 'react-chartjs-2';
import { X, TrendingUp, TrendingDown, ArrowUp, ArrowDown } from 'lucide-react';
import { AnomalyData, KPICard } from '../types/dashboard';
import {
  ComposableMap,
  Geographies,
  Geography,
  ZoomableGroup,
} from 'react-simple-maps';

const geoUrl = "https://cdn.jsdelivr.net/npm/us-atlas@3/states-10m.json";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

interface SummaryPanelProps {
  isOpen: boolean;
  onClose: () => void;
  data: AnomalyData | null;
}

const SummaryPanel: React.FC<SummaryPanelProps> = ({ isOpen, onClose, data }) => {
  if (!isOpen || !data) return null;

  const kpiCards: KPICard[] = [
    {
      title: 'Revenue',
      value: `$${(data.details.value / 1000).toFixed(0)}k`,
      momPercent: data.momPercent,
      yoyPercent: data.yoyPercent,
      trend: data.direction,
    },
    {
      title: 'Cart Rate',
      value: '12.3%',
      momPercent: -2.1,
      yoyPercent: 1.8,
      trend: 'down',
    },
    {
      title: 'Conversion',
      value: '8.7%',
      momPercent: 3.2,
      yoyPercent: 2.4,
      trend: 'up',
    },
    {
      title: 'AOV',
      value: '$247',
      momPercent: 1.5,
      yoyPercent: -0.8,
      trend: 'up',
    },
  ];

  // Revenue Decomposition Pie Chart Data
  const revenueDecompositionData = {
    labels: ['Trend', 'Seasonality', 'Residual'],
    datasets: [
      {
        data: [75, 20, 5],
        backgroundColor: ['#3b82f6', '#10b981', '#f59e0b'],
        borderColor: ['#1d4ed8', '#059669', '#d97706'],
        borderWidth: 2,
      },
    ],
  };

  const pieOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          padding: 20,
          usePointStyle: true,
        },
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            return `${context.label}: ${context.parsed}%`;
          },
        },
      },
    },
  };

  // Anomaly Attribution Bar Chart Data
  const anomalyAttributionData = {
    labels: Object.keys(data.details.attribution.Device || {}),
    datasets: [
      {
        label: 'Attribution Impact',
        data: Object.values(data.details.attribution.Device || {}),
        backgroundColor: Object.values(data.details.attribution.Device || {}).map((value: number) =>
          value > 0 ? 'rgba(39, 174, 96, 0.8)' : 'rgba(215, 38, 61, 0.8)'
        ),
        borderColor: Object.values(data.details.attribution.Device || {}).map((value: number) =>
          value > 0 ? 'rgba(39, 174, 96, 1)' : 'rgba(215, 38, 61, 1)'
        ),
        borderWidth: 1,
      },
    ],
  };

  const barOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            const value = context.parsed.y;
            return `Impact: $${(value / 1000).toFixed(1)}k`;
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: (value: any) => `$${(value / 1000).toFixed(0)}k`,
        },
      },
    },
  };

  const stateCodeMap: { [key: string]: string } = {
    'Alabama': 'AL', 'Alaska': 'AK', 'Arizona': 'AZ', 'Arkansas': 'AR', 'California': 'CA',
    'Colorado': 'CO', 'Connecticut': 'CT', 'Delaware': 'DE', 'Florida': 'FL', 'Georgia': 'GA',
    'Hawaii': 'HI', 'Idaho': 'ID', 'Illinois': 'IL', 'Indiana': 'IN', 'Iowa': 'IA',
    'Kansas': 'KS', 'Kentucky': 'KY', 'Louisiana': 'LA', 'Maine': 'ME', 'Maryland': 'MD',
    'Massachusetts': 'MA', 'Michigan': 'MI', 'Minnesota': 'MN', 'Mississippi': 'MS', 'Missouri': 'MO',
    'Montana': 'MT', 'Nebraska': 'NE', 'Nevada': 'NV', 'New Hampshire': 'NH', 'New Jersey': 'NJ',
    'New Mexico': 'NM', 'New York': 'NY', 'North Carolina': 'NC', 'North Dakota': 'ND', 'Ohio': 'OH',
    'Oklahoma': 'OK', 'Oregon': 'OR', 'Pennsylvania': 'PA', 'Rhode Island': 'RI', 'South Carolina': 'SC',
    'South Dakota': 'SD', 'Tennessee': 'TN', 'Texas': 'TX', 'Utah': 'UT', 'Vermont': 'VT',
    'Virginia': 'VA', 'Washington': 'WA', 'West Virginia': 'WV', 'Wisconsin': 'WI', 'Wyoming': 'WY'
  };

  // TreeMap data (simplified representation)
  const treeMapData = [
    { name: 'Mobile', value: 45, color: '#ef4444' },
    { name: 'Desktop', value: 30, color: '#22c55e' },
    { name: 'Tablet', value: 15, color: '#3b82f6' },
    { name: 'Other', value: 10, color: '#f59e0b' },
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-6xl max-h-[90vh] overflow-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h2 className="text-xl font-semibold text-gray-800">
              Anomaly on {data.period}
            </h2>
            <p className="text-gray-600 mt-1">
              Detailed analysis of revenue anomaly and contributing factors
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-8">
          {/* KPI Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {kpiCards.map((kpi, index) => (
              <div key={index} className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-600 mb-1">{kpi.title}</h3>
                <div className="text-2xl font-bold text-gray-800 mb-2">{kpi.value}</div>
                <div className="space-y-1">
                  <div className="flex items-center text-sm">
                    {kpi.momPercent > 0 ? (
                      <ArrowUp className="w-3 h-3 text-green-500 mr-1" />
                    ) : (
                      <ArrowDown className="w-3 h-3 text-red-500 mr-1" />
                    )}
                    <span className={`${kpi.momPercent > 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {Math.abs(kpi.momPercent).toFixed(1)}% MoM
                    </span>
                  </div>
                  <div className="flex items-center text-sm">
                    {kpi.yoyPercent > 0 ? (
                      <ArrowUp className="w-3 h-3 text-green-500 mr-1" />
                    ) : (
                      <ArrowDown className="w-3 h-3 text-red-500 mr-1" />
                    )}
                    <span className={`${kpi.yoyPercent > 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {Math.abs(kpi.yoyPercent).toFixed(1)}% YoY
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Revenue Decomposition */}
          <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Revenue Decomposition</h3>
            <div className="h-64">
              <Pie data={revenueDecompositionData} options={pieOptions} />
            </div>
          </div>

          {/* Second Row - US Map, Sources, and Attribution - 1:2:1 ratio */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Sources of Anomaly */}
            <div className="bg-gray-50 p-4 rounded-lg lg:col-span-1">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Sources of Anomaly</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-2 bg-white rounded border-l-4 border-red-500">
                  <span className="text-sm font-medium text-gray-700">Mobile Traffic Drop</span>
                  <span className="text-xs text-red-600 font-semibold">-18k</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-white rounded border-l-4 border-green-500">
                  <span className="text-sm font-medium text-gray-700">Desktop Conversion</span>
                  <span className="text-xs text-green-600 font-semibold">+8k</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-white rounded border-l-4 border-red-500">
                  <span className="text-sm font-medium text-gray-700">Promo Campaign</span>
                  <span className="text-xs text-red-600 font-semibold">-5k</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-white rounded border-l-4 border-green-500">
                  <span className="text-sm font-medium text-gray-700">Organic Growth</span>
                  <span className="text-xs text-green-600 font-semibold">+12k</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-white rounded border-l-4 border-red-500">
                  <span className="text-sm font-medium text-gray-700">Seasonal Effect</span>
                  <span className="text-xs text-red-600 font-semibold">-3k</span>
                </div>
              </div>
            </div>

            {/* US Map */}
            <div className="bg-gray-50 p-4 rounded-lg lg:col-span-2">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Geographic Impact</h3>
              <div className="h-64 border border-gray-200 rounded-lg overflow-hidden">
                <ComposableMap projection="geoAlbersUsa" className="w-full h-full">
                  <ZoomableGroup>
                    <Geographies geography={geoUrl}>
                      {({ geographies }) =>
                        geographies.map((geo) => {
                          const stateName = geo.properties.name;
                          const stateCode = stateCodeMap[stateName];
                          const stateData = data.details.attribution.Geography?.[stateCode];
                          
                          let fillColor = '#f3f4f6';
                          if (stateData) {
                            const maxValue = Math.max(...Object.values(data.details.attribution.Geography || {}).map(v => Math.abs(v)));
                            const intensity = Math.abs(stateData) / maxValue;
                            
                            if (stateData > 0) {
                              fillColor = `rgba(39, 174, 96, ${0.3 + intensity * 0.7})`;
                            } else {
                              fillColor = `rgba(215, 38, 61, ${0.3 + intensity * 0.7})`;
                            }
                          }
                          
                          return (
                            <Geography
                              key={geo.rsmKey}
                              geography={geo}
                              fill={fillColor}
                              stroke="#e5e7eb"
                              strokeWidth={0.5}
                              style={{
                                default: { outline: 'none' },
                                hover: { 
                                  outline: 'none',
                                  stroke: '#3b82f6',
                                  strokeWidth: 2,
                                  cursor: 'pointer'
                                },
                                pressed: { outline: 'none' }
                              }}
                            />
                          );
                        })
                      }
                    </Geographies>
                  </ZoomableGroup>
                </ComposableMap>
              </div>
            </div>

            {/* Anomaly Attribution */}
            <div className="bg-gray-50 p-4 rounded-lg lg:col-span-1">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Anomaly Attribution</h3>
              <div className="h-64">
                <Bar data={anomalyAttributionData} options={barOptions} />
              </div>
            </div>
          </div>

          {/* Third Row - Split Level Variation */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-gray-50 p-4 rounded-lg lg:col-span-2">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Split Level Variation</h3>
              <div className="h-64 relative bg-white rounded border">
                <svg viewBox="0 0 300 180" className="w-full h-full p-2">
                  {/* Mobile - largest rectangle */}
                  <rect
                    x="5"
                    y="5"
                    width="135"
                    height="80"
                    fill="#ef4444"
                    opacity="0.8"
                    rx="4"
                    className="cursor-pointer hover:opacity-100 transition-opacity"
                  />
                  <text
                    x="72.5"
                    y="50"
                    textAnchor="middle"
                    className="text-xs font-medium fill-white"
                  >
                    Mobile (45%)
                  </text>
                    
                  {/* Desktop - second largest */}
                  <rect
                    x="150"
                    y="5"
                    width="90"
                    height="80"
                    fill="#22c55e"
                    opacity="0.8"
                    rx="4"
                    className="cursor-pointer hover:opacity-100 transition-opacity"
                  />
                  <text
                    x="195"
                    y="50"
                    textAnchor="middle"
                    className="text-xs font-medium fill-white"
                  >
                    Desktop (30%)
                  </text>
                  
                  {/* Tablet - medium rectangle */}
                  <rect
                    x="5"
                    y="95"
                    width="80"
                    height="50"
                    fill="#3b82f6"
                    opacity="0.8"
                    rx="4"
                    className="cursor-pointer hover:opacity-100 transition-opacity"
                  />
                  <text
                    x="45"
                    y="125"
                    textAnchor="middle"
                    className="text-xs font-medium fill-white"
                  >
                    Tablet (15%)
                  </text>
                  
                  {/* Other - smallest rectangle */}
                  <rect
                    x="95"
                    y="95"
                    width="60"
                    height="50"
                    fill="#f59e0b"
                    opacity="0.8"
                    rx="4"
                    className="cursor-pointer hover:opacity-100 transition-opacity"
                  />
                  <text
                    x="125"
                    y="125"
                    textAnchor="middle"
                    className="text-xs font-medium fill-white"
                  >
                    Other (10%)
                  </text>
                </svg>
              </div>
            </div>
          </div>

          {/* Attribution Details */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {Object.entries(data.details.attribution).map(([category, items]) => (
              <div key={category} className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">{category} Attribution</h3>
                <div className="space-y-2">
                  {Object.entries(items).map(([item, value]) => (
                    <div key={item} className="flex justify-between items-center">
                      <span className="text-gray-600">{item}</span>
                      <span className={`font-semibold ${value > 0 ? 'text-green-600' : 'text-red-600'}`}>
                        ${(value / 1000).toFixed(1)}k
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SummaryPanel;
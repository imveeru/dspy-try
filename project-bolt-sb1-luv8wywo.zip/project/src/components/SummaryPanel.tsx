import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Pie, Bar } from 'react-chartjs-2';
import { X, TrendingUp, TrendingDown, ArrowUp, ArrowDown } from 'lucide-react';
import { AnomalyData, KPICard } from '../types/dashboard';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

interface SummaryPanelProps {
  isOpen: boolean;
  onClose: () => void;
  data: AnomalyData | null;
}

const SummaryPanel: React.FC<SummaryPanelProps> = ({ isOpen, onClose, data }) => {
  if (!isOpen || !data) return null;

  const kpiCards: KPICard[] = [
    {
      title: 'Revenue',
      value: `$${(data.details.value / 1000).toFixed(0)}k`,
      momPercent: data.momPercent,
      yoyPercent: data.yoyPercent,
      trend: data.direction,
    },
    {
      title: 'Cart Rate',
      value: '12.3%',
      momPercent: -2.1,
      yoyPercent: 1.8,
      trend: 'down',
    },
    {
      title: 'Conversion',
      value: '8.7%',
      momPercent: 3.2,
      yoyPercent: 2.4,
      trend: 'up',
    },
    {
      title: 'AOV',
      value: '$247',
      momPercent: 1.5,
      yoyPercent: -0.8,
      trend: 'up',
    },
  ];

  // Revenue Decomposition Pie Chart Data
  const revenueDecompositionData = {
    labels: ['Trend', 'Seasonality', 'Residual'],
    datasets: [
      {
        data: [75, 20, 5],
        backgroundColor: ['#3b82f6', '#10b981', '#f59e0b'],
        borderColor: ['#1d4ed8', '#059669', '#d97706'],
        borderWidth: 2,
      },
    ],
  };

  const pieOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          padding: 20,
          usePointStyle: true,
        },
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            return `${context.label}: ${context.parsed}%`;
          },
        },
      },
    },
  };

  // Anomaly Attribution Bar Chart Data
  const anomalyAttributionData = {
    labels: Object.keys(data.details.attribution.Device || {}),
    datasets: [
      {
        label: 'Attribution Impact',
        data: Object.values(data.details.attribution.Device || {}),
        backgroundColor: Object.values(data.details.attribution.Device || {}).map((value: number) =>
          value > 0 ? 'rgba(39, 174, 96, 0.8)' : 'rgba(215, 38, 61, 0.8)'
        ),
        borderColor: Object.values(data.details.attribution.Device || {}).map((value: number) =>
          value > 0 ? 'rgba(39, 174, 96, 1)' : 'rgba(215, 38, 61, 1)'
        ),
        borderWidth: 1,
      },
    ],
  };

  const barOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            const value = context.parsed.y;
            return `Impact: $${(value / 1000).toFixed(1)}k`;
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: (value: any) => `$${(value / 1000).toFixed(0)}k`,
        },
      },
    },
  };

  // TreeMap data (simplified representation)
  const treeMapData = [
    { name: 'Mobile', value: 45, color: '#ef4444' },
    { name: 'Desktop', value: 30, color: '#22c55e' },
    { name: 'Tablet', value: 15, color: '#3b82f6' },
    { name: 'Other', value: 10, color: '#f59e0b' },
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-6xl max-h-[90vh] overflow-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h2 className="text-xl font-semibold text-gray-800">
              Anomaly on {data.period}
            </h2>
            <p className="text-gray-600 mt-1">
              Detailed analysis of revenue anomaly and contributing factors
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-8">
          {/* KPI Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {kpiCards.map((kpi, index) => (
              <div key={index} className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-600 mb-1">{kpi.title}</h3>
                <div className="text-2xl font-bold text-gray-800 mb-2">{kpi.value}</div>
                <div className="space-y-1">
                  <div className="flex items-center text-sm">
                    {kpi.momPercent > 0 ? (
                      <ArrowUp className="w-3 h-3 text-green-500 mr-1" />
                    ) : (
                      <ArrowDown className="w-3 h-3 text-red-500 mr-1" />
                    )}
                    <span className={`${kpi.momPercent > 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {Math.abs(kpi.momPercent).toFixed(1)}% MoM
                    </span>
                  </div>
                  <div className="flex items-center text-sm">
                    {kpi.yoyPercent > 0 ? (
                      <ArrowUp className="w-3 h-3 text-green-500 mr-1" />
                    ) : (
                      <ArrowDown className="w-3 h-3 text-red-500 mr-1" />
                    )}
                    <span className={`${kpi.yoyPercent > 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {Math.abs(kpi.yoyPercent).toFixed(1)}% YoY
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Revenue Decomposition */}
          <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Revenue Decomposition</h3>
            <div className="h-64">
              <Pie data={revenueDecompositionData} options={pieOptions} />
            </div>
          </div>

          {/* Bottom Row - Attribution Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Anomaly Attribution */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Anomaly Attribution</h3>
              <div className="h-64">
                <Bar data={anomalyAttributionData} options={barOptions} />
              </div>
            </div>

            {/* Split Level Variation - TreeMap */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Split Level Variation</h3>
              <div className="h-64 relative">
                <svg viewBox="0 0 400 200" className="w-full h-full">
                  {treeMapData.map((item, index) => {
                    const width = (item.value / 100) * 400;
                    const height = 40;
                    const y = index * 50;
                    
                    return (
                      <g key={item.name}>
                        <rect
                          x="0"
                          y={y}
                          width={width}
                          height={height}
                          fill={item.color}
                          opacity="0.8"
                          rx="4"
                          className="cursor-pointer hover:opacity-100 transition-opacity"
                        />
                        <text
                          x={width / 2}
                          y={y + height / 2 + 5}
                          textAnchor="middle"
                          className="text-xs font-medium fill-white"
                        >
                          {item.name} ({item.value}%)
                        </text>
                      </g>
                    );
                  })}
                </svg>
              </div>
            </div>
          </div>

          {/* Attribution Details - Moved to bottom */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {Object.entries(data.details.attribution).map(([category, items]) => (
              <div key={category} className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">{category} Attribution</h3>
                <div className="space-y-2">
                  {Object.entries(items).map(([item, value]) => (
                    <div key={item} className="flex justify-between items-center">
                      <span className="text-gray-600">{item}</span>
                      <span className={`font-semibold ${value > 0 ? 'text-green-600' : 'text-red-600'}`}>
                        ${(value / 1000).toFixed(1)}k
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SummaryPanel;
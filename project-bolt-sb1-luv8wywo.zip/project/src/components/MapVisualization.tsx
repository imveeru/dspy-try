import React from 'react';
import {
  ComposableMap,
  Geographies,
  Geography,
  ZoomableGroup,
} from 'react-simple-maps';
import { MapData } from '../types/dashboard';

const geoUrl = "https://cdn.jsdelivr.net/npm/us-atlas@3/states-10m.json";

interface MapVisualizationProps {
  data: MapData;
  onStateClick: (stateCode: string, stateData: any) => void;
}

const MapVisualization: React.FC<MapVisualizationProps> = ({ data, onStateClick }) => {
  const getStateColor = (stateCode: string) => {
    const stateData = data.states[stateCode];
    if (!stateData) return '#f3f4f6';
    
    const maxValue = Math.max(...Object.values(data.states).map(s => Math.abs(s.value)));
    const intensity = Math.abs(stateData.value) / maxValue;
    
    if (stateData.value > 0) {
      return `rgba(39, 174, 96, ${0.3 + intensity * 0.7})`;
    } else {
      return `rgba(215, 38, 61, ${0.3 + intensity * 0.7})`;
    }
  };

  const stateCodeMap: { [key: string]: string } = {
    'Alabama': 'AL', 'Alaska': 'AK', 'Arizona': 'AZ', 'Arkansas': 'AR', 'California': 'CA',
    'Colorado': 'CO', 'Connecticut': 'CT', 'Delaware': 'DE', 'Florida': 'FL', 'Georgia': 'GA',
    'Hawaii': 'HI', 'Idaho': 'ID', 'Illinois': 'IL', 'Indiana': 'IN', 'Iowa': 'IA',
    'Kansas': 'KS', 'Kentucky': 'KY', 'Louisiana': 'LA', 'Maine': 'ME', 'Maryland': 'MD',
    'Massachusetts': 'MA', 'Michigan': 'MI', 'Minnesota': 'MN', 'Mississippi': 'MS', 'Missouri': 'MO',
    'Montana': 'MT', 'Nebraska': 'NE', 'Nevada': 'NV', 'New Hampshire': 'NH', 'New Jersey': 'NJ',
    'New Mexico': 'NM', 'New York': 'NY', 'North Carolina': 'NC', 'North Dakota': 'ND', 'Ohio': 'OH',
    'Oklahoma': 'OK', 'Oregon': 'OR', 'Pennsylvania': 'PA', 'Rhode Island': 'RI', 'South Carolina': 'SC',
    'South Dakota': 'SD', 'Tennessee': 'TN', 'Texas': 'TX', 'Utah': 'UT', 'Vermont': 'VT',
    'Virginia': 'VA', 'Washington': 'WA', 'West Virginia': 'WV', 'Wisconsin': 'WI', 'Wyoming': 'WY'
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h2 className="text-lg font-semibold text-gray-800 mb-4">
        Geographic Anomaly Distribution
      </h2>
      
      <div className="relative">
        <div className="w-full h-80 border border-gray-200 rounded-lg overflow-hidden">
          <ComposableMap projection="geoAlbersUsa" className="w-full h-full">
            <ZoomableGroup>
              <Geographies geography={geoUrl}>
                {({ geographies }) =>
                  geographies.map((geo) => {
                    const stateName = geo.properties.name;
                    const stateCode = stateCodeMap[stateName];
                    const stateData = data.states[stateCode];
                    
                    return (
                      <Geography
                        key={geo.rsmKey}
                        geography={geo}
                        fill={getStateColor(stateCode)}
                        stroke="#e5e7eb"
                        strokeWidth={0.5}
                        style={{
                          default: { outline: 'none' },
                          hover: { 
                            outline: 'none',
                            stroke: '#3b82f6',
                            strokeWidth: 2,
                            cursor: 'pointer'
                          },
                          pressed: { outline: 'none' }
                        }}
                        onClick={() => {
                          if (stateData) {
                            onStateClick(stateCode, stateData);
                          }
                        }}
                      />
                    );
                  })
                }
              </Geographies>
            </ZoomableGroup>
          </ComposableMap>
        </div>
        
        <div className="flex items-center justify-center mt-4 space-x-6 text-sm">
          <div className="flex items-center">
            <div className="w-4 h-4 bg-green-400 rounded mr-2"></div>
            <span className="text-gray-600">Positive Impact</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 bg-red-400 rounded mr-2"></div>
            <span className="text-gray-600">Negative Impact</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MapVisualization;
import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { TimeSeriesData } from '../types/dashboard';
import { format, parseISO } from 'date-fns';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface RevenueChartProps {
  data: TimeSeriesData[];
  onAnomalyClick: (data: TimeSeriesData) => void;
  startDate: string;
  endDate: string;
}

const RevenueChart: React.FC<RevenueChartProps> = ({ 
  data, 
  onAnomalyClick, 
  startDate, 
  endDate 
}) => {
  const chartData = {
    labels: data.map(item => format(parseISO(item.date), 'MMM dd')),
    datasets: [
      {
        label: 'Revenue',
        data: data.map(item => item.revenue),
        borderColor: '#1f2937',
        backgroundColor: 'rgba(31, 41, 55, 0.1)',
        borderWidth: 2,
        fill: false,
        tension: 0.1,
        pointBackgroundColor: data.map(item => {
          if (!item.anomaly) return '#1f2937';
          return item.direction === 'up' ? '#27AE60' : '#D7263D';
        }),
        pointBorderColor: data.map(item => {
          if (!item.anomaly) return '#1f2937';
          return item.direction === 'up' ? '#27AE60' : '#D7263D';
        }),
        pointRadius: data.map(item => item.anomaly ? 8 : 4),
        pointHoverRadius: data.map(item => item.anomaly ? 10 : 6),
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            const dataIndex = context.dataIndex;
            const item = data[dataIndex];
            const value = `$${(context.parsed.y / 1000).toFixed(0)}k`;
            
            if (item.anomaly) {
              return [
                `Revenue: ${value}`,
                `Anomaly: ${item.direction === 'up' ? 'Positive' : 'Negative'}`,
                'Click for details'
              ];
            }
            return `Revenue: ${value}`;
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: false,
        ticks: {
          callback: (value: any) => `$${(value / 1000).toFixed(0)}k`,
        },
        grid: {
          color: 'rgba(0, 0, 0, 0.1)',
        },
      },
      x: {
        grid: {
          color: 'rgba(0, 0, 0, 0.1)',
        },
      },
    },
    onClick: (event: any, elements: any) => {
      if (elements.length > 0) {
        const dataIndex = elements[0].index;
        const clickedData = data[dataIndex];
        if (clickedData.anomaly) {
          onAnomalyClick(clickedData);
        }
      }
    },
    interaction: {
      intersect: false,
      mode: 'index' as const,
    },
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h2 className="text-lg font-semibold text-gray-800 mb-4">
        Revenue and anomalies over the period - {format(parseISO(startDate), 'MM/yyyy')} to {format(parseISO(endDate), 'MM/yyyy')}
      </h2>
      <div className="h-80">
        <Line data={chartData} options={options} />
      </div>
      <div className="flex items-center justify-center mt-4 space-x-6 text-sm">
        <div className="flex items-center">
          <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
          <span className="text-gray-600">Positive Anomaly</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
          <span className="text-gray-600">Negative Anomaly</span>
        </div>
      </div>
    </div>
  );
};

export default RevenueChart;
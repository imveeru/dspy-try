export interface TimeSeriesData {
  date: string;
  revenue: number;
  anomaly: boolean;
  direction: 'up' | 'down' | null;
  week: string;
}

export interface AnomalyData {
  week: string;
  period: string;
  metric: string;
  anomalyScore: number;
  direction: 'up' | 'down';
  momPercent: number;
  yoyPercent: number;
  details: {
    value: number;
    attribution: {
      [category: string]: {
        [subcategory: string]: number;
      };
    };
  };
}

export interface MapData {
  states: {
    [stateCode: string]: {
      name: string;
      value: number;
      anomalyScore: number;
      direction: 'up' | 'down';
    };
  };
}

export interface FilterType {
  id: string;
  label: string;
  active: boolean;
}

export interface KPICard {
  title: string;
  value: string;
  momPercent: number;
  yoyPercent: number;
  trend: 'up' | 'down';
}
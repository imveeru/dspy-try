import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import RevenueChart from './components/RevenueChart';
import AnomalyTable from './components/AnomalyTable';
import MapVisualization from './components/MapVisualization';
import AttributionChart from './components/AttributionChart';
import SummaryPanel from './components/SummaryPanel';
import { TimeSeriesData, AnomalyData, MapData } from './types/dashboard';

// Import mock data
import timeSeriesData from './data/timeSeriesData.json';
import anomaliesData from './data/anomaliesData.json';
import mapData from './data/mapData.json';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [startDate, setStartDate] = useState('2024-01-01');
  const [endDate, setEndDate] = useState('2024-03-18');
  const [summaryPanelOpen, setSummaryPanelOpen] = useState(false);
  const [selectedAnomaly, setSelectedAnomaly] = useState<AnomalyData | null>(null);
  const [attributionData, setAttributionData] = useState<{ [key: string]: number }>({
    Mobile: -18000,
    Desktop: 8000,
    Tablet: 2000,
    Promo: -5000,
    Organic: 12000,
  });

  const handleAnomalyClick = (timeSeriesItem: TimeSeriesData) => {
    // Find corresponding anomaly data
    const anomaly = anomaliesData.find(a => a.week === timeSeriesItem.week);
    if (anomaly) {
      setSelectedAnomaly(anomaly);
      setSummaryPanelOpen(true);
    }
  };

  const handleTableRowClick = (anomaly: AnomalyData) => {
    setSelectedAnomaly(anomaly);
    setSummaryPanelOpen(true);
  };

  const handleStateClick = (stateCode: string, stateData: any) => {
    // Update attribution data based on selected state
    const newAttributionData = {
      Device: stateData.value * 0.6,
      Category: stateData.value * 0.3,
      Geography: stateData.value * 0.1,
    };
    setAttributionData(newAttributionData);
    
    // Find and show anomaly for the selected state
    const anomaly = anomaliesData[0]; // Use first anomaly as example
    setSelectedAnomaly(anomaly);
    setSummaryPanelOpen(true);
  };

  const handleBarClick = (segment: string, value: number) => {
    console.log(`Clicked ${segment}: ${value}`);
    // Could trigger additional analysis or filtering
  };

  return (
    <div className="min-h-screen bg-gray-100" style={{ fontFamily: 'DM Sans, sans-serif' }}>
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
      
      <div className="ml-16 p-6">
        <Header
          startDate={startDate}
          endDate={endDate}
          onStartDateChange={setStartDate}
          onEndDateChange={setEndDate}
        />

        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            {/* Top Section */}
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <RevenueChart
                data={timeSeriesData as TimeSeriesData[]}
                onAnomalyClick={handleAnomalyClick}
                startDate={startDate}
                endDate={endDate}
              />
              <AnomalyTable
                data={anomaliesData as AnomalyData[]}
                onRowClick={handleTableRowClick}
              />
            </div>

            {/* Bottom Section */}
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <MapVisualization
                data={mapData as MapData}
                onStateClick={handleStateClick}
              />
              <AttributionChart
                data={attributionData}
                onBarClick={handleBarClick}
              />
            </div>
          </div>
        )}

        {activeTab === 'anomalies' && (
          <div className="bg-white p-8 rounded-lg shadow-sm text-center">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Anomalies View</h2>
            <p className="text-gray-600">Detailed anomaly analysis and management tools will be available here.</p>
          </div>
        )}

        {activeTab === 'geography' && (
          <div className="bg-white p-8 rounded-lg shadow-sm text-center">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Geography View</h2>
            <p className="text-gray-600">Geographic analysis and regional performance metrics will be displayed here.</p>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="bg-white p-8 rounded-lg shadow-sm text-center">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Settings</h2>
            <p className="text-gray-600">Dashboard configuration and user preferences will be managed here.</p>
          </div>
        )}
      </div>

      <SummaryPanel
        isOpen={summaryPanelOpen}
        onClose={() => setSummaryPanelOpen(false)}
        data={selectedAnomaly}
      />
    </div>
  );
}

export default App;